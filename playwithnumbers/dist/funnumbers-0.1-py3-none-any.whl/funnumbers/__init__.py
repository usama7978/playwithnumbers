def add_num(a,b):
    return a+b

def sub_num(a,b):
    return a-b    

def multi_num(a,b):
    return a*b

def divid_num(a,b):
    return a/b

def power_num(a,b):
    return a**b   

         